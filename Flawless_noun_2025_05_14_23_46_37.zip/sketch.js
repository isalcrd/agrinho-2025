function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let plantHeight = 0;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  // Desenhar o solo
  fill(139, 69, 19); // Cor marrom para o solo
  rect(0, height - 50, width, 50);
  
  // Desenhar a planta
  fill(34, 139, 34); // Cor verde para a planta
  rect(width / 2 - 10, height - 50 - plantHeight, 20, plantHeight);
  
  // Aumentar a altura da planta
  if (plantHeight < 100) {
    plantHeight += 1; // A planta cresce
  }
}